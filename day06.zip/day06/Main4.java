//package day06;
//
//class A4{
//
//    void show(){
//        System.out.println("Zero");
//    }
//    public static void show(){
//        System.out.println("First");
//    }
//
//    public static void show(String x){
//        System.out.println("String");
//    }
//}
//
//public class Main4 {
//    public static void main(String[] args) {
//        A4 a4 = new A4();
//        a4.show();
//        A4.show(10);
//        A4.show("Suraj");
//    }
//}
////We cannot overolaad one static and one normla method at same time it will complie time error